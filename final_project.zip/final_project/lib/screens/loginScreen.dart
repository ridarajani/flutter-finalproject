import 'package:flutter/material.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: GestureDetector(
          child: Padding(
            padding: EdgeInsets.symmetric(
              horizontal: 10,
            ),
            child: CircleAvatar(
              backgroundImage: NetworkImage('https://picsum.photos/200/300'),
              backgroundColor: Colors.white,
              radius: 10,
            ),
          ),
        ),
        backgroundColor: Colors.white,
        title: SizedBox(
          height: 35,
          child: TextField(
            decoration: InputDecoration(
              fillColor: Color.fromARGB(255, 205, 218, 230),
              filled: true,
              prefixIcon: Icon(Icons.search),
              labelText: 'Enter Name',

            ),
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 0, top: 5),
            child: Stack(
              children: [
                IconButton(
                  icon: Icon(Icons.chat),
                  color: Colors.grey,
                  onPressed: () {},
                  iconSize: 25,
                ),
              ],
            ),
          ),
        ],
      ),
      body: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: 10,
            vertical: 10,
          ),
          child: Row(children: <Widget>[
            const Image(
              image: NetworkImage(
                  'https://flutter.github.io/assets-for-api-docs/assets/widgets/owl.jpg'),
              width: 50,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 10,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        "React Tree",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Text("1,221 followers"),
                    ],
                  ),
                  Row(
                    children: [Text("6h ."), Icon(Icons.public ,size: 15,)],
                  ),
                ],
              ),
            ),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: 15,
            vertical: 10,
          ),
          child: Text(
              "In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the"),
        ),
        const Image(
          image: NetworkImage(
              'https://flutter.github.io/assets-for-api-docs/assets/widgets/owl.jpg'),
        ),
        Row(children: [
          Icon(
            Icons.heart_broken,
            color: Colors.red,
          ),
          Icon(
            Icons.thumb_up,
            color: Colors.blue,
          ),
          // Stack(
          //   alignment: Alignment.bottomCenter,
          //   children: <Widget>[
          //     Icon(
          //       Icons.heart_broken,
          //       color: Colors.red,
          //     ),
          //     Positioned(
          //       left: 5,
          //       child: Icon(
          //         Icons.thumb_up,
          //         color: Colors.blue,
          //       ),
          //     ),
          //   ],

          // ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text('Irtiza Khan and 2 others'),
          )
        ]),
        Divider(
          height: 6,
          color: Colors.grey,
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Column(children: [
                Icon(Icons.thumb_up, size: 18, color: Color.fromARGB(255, 133, 127, 127)),
                Text(
                  'Like',
                  style: TextStyle(color: Color.fromARGB(255, 133, 127, 127)),
                )
              ]),
              Column(children: [
                Icon(Icons.sms, size: 18, color: Color.fromARGB(255, 133, 127, 127)),
                Text(
                  'Comments',
                  style: TextStyle(color: Color.fromARGB(255, 133, 127, 127)),
                )
              ]),
              Column(children: [
                Icon(Icons.share, size: 18, color: Color.fromARGB(255, 133, 127, 127)),
                Text(
                  'Share',
                  style: TextStyle(color: Color.fromARGB(255, 133, 127, 127)),
                )
              ]),
              Column(children: [
                Icon(Icons.send, size: 18, color: Color.fromARGB(255, 133, 127, 127)),
                Text(
                  'Send',
                  style: TextStyle(color: Color.fromARGB(255, 133, 127, 127)),
                )
              ]),
            ],
          ),
        )
      ]),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.network_cell),
            label: 'My Network',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.post_add),
            label: 'Post',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.notification_add),
            label: 'Notifications',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.join_inner),
            label: 'Jobs',
          ),
        ],
      ),
    );
  }
}
